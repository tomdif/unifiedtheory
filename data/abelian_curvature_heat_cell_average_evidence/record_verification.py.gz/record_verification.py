from pathlib import Path
import datetime, gzip, hashlib, json, re, subprocess
root = Path('/Users/thomasdifiore/unifiedtheory')
tmp = Path('/tmp/unifiedtheory-heat-pde')
modules = ['AbelianCurvatureHeatPDE', 'AbelianCurvatureHeatGridInversion', 'AbelianCurvatureHeatCellAverage']
expected = {m: ['UnifiedTheory.LayerA.'+m+'.'+n for n in re.findall(r'^theorem (\w+)',
    (root/'UnifiedTheory/LayerA'/f'{m}.lean').read_text(), re.M)] for m in modules}
assert 'Build completed successfully' in (tmp/'final-build.log').read_text()
raw = (tmp/'axioms.log').read_text()
assert 'error:' not in raw
checked = {name: sorted(a.strip() for a in axioms.split(',') if a.strip())
    for name, axioms in re.findall(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]", raw)}
assert set(checked) == {n for ns in expected.values() for n in ns}
allowed = {'propext', 'Classical.choice', 'Quot.sound'}
assert all(set(ax) <= allowed for ax in checked.values())
evidence = root/'data/abelian_curvature_heat_cell_average_evidence'
evidence.mkdir(exist_ok=True)
for filename in ['final-build.log','axioms.log','ym-ledger.log','toe-ledger.log','record_verification.py']:
    (evidence/(filename+'.gz')).write_bytes(gzip.compress((tmp/filename).read_bytes(), mtime=0))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
sources = ['UnifiedTheory/LayerA/'+m+'.lean' for m in modules +
    ['AbelianCurvatureHeat', 'AbelianCurvatureHeatDynamics', 'AbelianCurvatureHeatFourier',
     'AbelianCurvatureHeatContinuum', 'AbelianCurvatureHeatGridLimit']]
sources += ['scripts/CheckAbelianCurvatureHeatCellAverage.lean', 'scripts/audit_repository.py',
    'scripts/check_yang_mills_requirements.py', 'scripts/validate_toe_attack_ledger.py',
    'README.md', 'STATUS.md', 'OPEN_OBLIGATIONS_ATTACK.md', 'ABELIAN_CURVATURE_HEAT_LIMIT.md',
    'lean-toolchain', 'lakefile.toml', 'lake-manifest.json']
record = {
    'schema_version': 1,
    'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Actual cell-average initialization, qualitative positive-time grid heat limit, and continuum heat PDE in two dimensions',
    'base_commit': subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    'workspace_state': 'Local uncommitted work; pre-existing research changes preserved',
    'build': {'passed': True, 'target': 'UnifiedTheory.LayerA.AbelianCurvatureHeatCellAverage',
              'whole_repository_build': False},
    'axiom_check': {'passed': True, 'checked_declarations': len(checked),
                    'allowed_axioms': sorted(allowed), 'declarations': checked},
    'modules': {m: {'theorem_count': len(ns)} for m,ns in expected.items()},
    'main_result': {
        'declaration': 'UnifiedTheory.LayerA.AbelianCurvatureHeatCellAverage.bounded_cellAverage_limit',
        'initial_datum': 'An almost-everywhere strongly measurable, essentially bounded real function on the unit square with restricted Lebesgue measure',
        'initial_grid': 'Exact real cell integrals multiplied by (n+1)^2',
        'conclusion': 'The actual Poisson-series gridHeat converges uniformly over all grid nodes at every fixed strictly positive time to the real continuum Fourier series',
        'coefficient_bounds_and_consistency': 'Derived from integration, not assumed',
        'cell_geometry': 'The modular cells restricted to the unit square equal the ordinary half-open rectangles; their measure is proved to be 1/(n+1)^2',
        'frequency_convention': '-1/2 <= h*k_j < 1/2, with exact normalized inversion',
        'underlying_complex_extension': 'The coefficient construction and convergence require only integrability'
    },
    'pde_result': {
        'declarations': [
            'UnifiedTheory.LayerA.AbelianCurvatureHeatPDE.continuum_heat_equation',
            'UnifiedTheory.LayerA.AbelianCurvatureHeatPDE.real_heat_equation',
            'UnifiedTheory.LayerA.AbelianCurvatureHeatCellAverage.cellAverage_limit_heat_equation'],
        'equation': 'partial_t u = partial_x^2 u + partial_y^2 u at every t > 0',
        'derivative_interchange': 'Proved with summable Gaussian majorants for polynomially bounded Fourier coefficients; second spatial derivatives use the result twice'
    },
    'remaining_formal_obligations': [
        'L2 initial trace and continuum initial-data uniqueness',
        'Quantitative estimates uniform over positive time intervals',
        'Final axial gauge reconstruction and path-transport assembly'],
    'scientific_boundary': 'Classical scalar Abelian diffusion; no four-dimensional quantum Yang-Mills or TOE completion',
    'physical_ledgers': {
        'yang_mills': json.loads((tmp/'ym-ledger.log').read_text()),
        'toe': (tmp/'toe-ledger.log').read_text().strip(),
        'gate_statuses_changed': False},
    'prior_records': 'Earlier JSON reports remain historical checkpoints; their documentation hashes precede the current extension.',
    'source_sha256': {s:sha(root/s) for s in sources},
    'evidence_sha256': {str(p.relative_to(root)):sha(p) for p in sorted(evidence.glob('*.gz'))}
}
path = root/'data/abelian_curvature_heat_cell_average_verification.json'
path.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'checked_declarations':len(checked),'allowed_axioms_only':True,'report':str(path)}))
