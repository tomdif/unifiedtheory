import numpy as np
from scipy import linalg
import itertools,sys,time
sys.path.insert(0,'scripts')
from overlap_chirality_audit import GAMMA,GAMMA5
exec(open('/tmp/unifiedtheory-chiral-comparison/curved_probe.py').read().split('for N in [')[0])
gamma=np.array([np.array(g,complex) for g in GAMMA]);g5small=np.array(GAMMA5,complex)

def setup(N):
 a=2*np.pi/N;sites=np.array(list(itertools.product(range(N),repeat=2)));n=N*N;indices={tuple(p):i for i,p in enumerate(sites)}
 theta=np.zeros((4,n),complex)
 for mu,k,c in terms:
  f=np.exp(1j*a*(sites@np.array(k)))
  kmu=k[mu] if mu<2 else 0
  integral=(1-np.exp(-1j*kmu*a))/(1j*kmu) if kmu else a
  theta[mu]+=c*integral*f+np.conj(c*integral*f)
 theta=theta.real
 previous=[np.array([indices[tuple((v-1)%N if i==mu else v for i,v in enumerate(x))] for x in sites]) for mu in range(2)]
 g5=np.kron(g5small,np.eye(n));eye=np.eye(4*n);plus=[(np.eye(4)+g)/2 for g in gamma];minus=[np.eye(4)-p for p in plus]
 return theta,previous,g5,eye,plus,minus

def current(N,z,k2,k3,st):
 theta,previous,g5,eye,plus,minus=st;n=N*N
 W=3*eye.astype(complex);dW=np.zeros_like(W)
 for mu in range(4):
  vals=np.exp(1j*z*theta[mu]);ders=1j*theta[mu]
  if mu<2:
   T=np.zeros((n,n),complex);Ti=np.zeros_like(T);dT=np.zeros_like(T);dTi=np.zeros_like(T)
   T[np.arange(n),previous[mu]]=vals;Ti[previous[mu],np.arange(n)]=1/vals
   dT[np.arange(n),previous[mu]]=ders*vals;dTi[previous[mu],np.arange(n)]=-ders/vals
  else:
   shift=np.exp(-1j*(k2 if mu==2 else k3));vals=vals*shift
   T=np.diag(vals);Ti=np.diag(1/vals);dT=np.diag(ders*vals);dTi=np.diag(-ders/vals)
  W-=np.kron(plus[mu],T)+np.kron(minus[mu],Ti)
  dW-=np.kron(plus[mu],dT)+np.kron(minus[mu],dTi)
 H=g5@W;dH=g5@dW
 vals,v=linalg.eig(H,check_finite=False);iv=linalg.inv(v,check_finite=False);sgn=np.where(vals.real>0,1.,-1.)
 divided=np.zeros((len(vals),len(vals)),complex);mask=sgn[:,None]!=sgn[None,:];den=vals[:,None]-vals[None,:];num=sgn[:,None]-sgn[None,:];divided[mask]=num[mask]/den[mask]
 eps=(v*sgn)@iv;deps=v@(divided*(iv@dH@v))@iv
 D=eye+g5@eps;dD=g5@deps
 response=linalg.solve(D.T,dD.T,check_finite=False).T
 # fixed codomain P_minus => positive chirality domain, as in Hsu.
 return np.trace(response[2*n:,2*n:])

def calc_lattice(N,angles=12,radius=1):
 st=setup(N);a=2*np.pi/N;ans=0j
 for j in range(angles):
  phi=2*np.pi*j/angles;z=radius*np.exp(1j*phi);block=0j
  for n2 in range(-N//2,N-N//2):
   for n3 in range(-N//2,N-N//2):block+=current(N,z,a*n2,a*(n3+.5),st)
  ans+=block*np.exp(-4j*phi)/angles/radius**4
 return ans
for N,angles,radius in [(4,16,1),(4,16,.7),(6,16,1),(10,12,1),(12,12,1)]:
 t=time.time();v=calc_lattice(N,angles,radius);print('LATTICE',N,angles,radius,v,time.time()-t,flush=True)
