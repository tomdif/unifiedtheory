import numpy as np
from scipy import sparse
import itertools,time
sig=np.array([[[0,1],[1,0]],[[0,-1j],[1j,0]],[[1,0],[0,-1]]],complex)
# (component, frequency, complex coefficient); each adds its conjugate partner.
terms=[(0,(1,0),-.05j),(0,(1,1),.02),(1,(0,1),-.035j),(1,(2,-1),.015),(2,(1,0),.045),(2,(1,1),-.03j),(3,(0,1),.04),(3,(2,-1),-.025j)]
def calc(cutoff):
 labels=np.arange(-cutoff,cutoff+1); points=list(itertools.product(labels,repeat=2)); index={p:i for i,p in enumerate(points)}; nn=len(points)
 parts=[]
 for mu in range(4):
  rr=[];cc=[];vv=[]
  for m,k,c in terms:
   if mu!=m:continue
   for freq,z in [(k,c),(tuple(-x for x in k),np.conj(c))]:
    for j,p in enumerate(points):
     target=tuple(x+y for x,y in zip(p,freq))
     if target in index:rr.append(index[target]);cc.append(j);vv.append(z)
  A=sparse.csr_matrix((vv,(rr,cc)),shape=(nn,nn))
  spin=-1j*sig[mu] if mu<3 else np.eye(2)
  parts.append(sparse.kron(A,spin,format='csr'))
 V=sum(parts);total=0j
 for p2 in labels:
  for p3 in np.arange(-cutoff-1,cutoff+1)+.5:
   blocks=[]
   for p0,p1 in points:
    D=1j*(p0*sig[0]+p1*sig[1]+p2*sig[2])-p3*np.eye(2)
    blocks.append(np.linalg.inv(D))
   K=sparse.block_diag(blocks,format='csr')@V; K2=K@K;K3=K2@K
   total+=K2.multiply(K3.T).sum()
 return total
for N in [2,3,4,6,8,12,16]:
 t=time.time();v=calc(N);print(N,v,time.time()-t,flush=True)
