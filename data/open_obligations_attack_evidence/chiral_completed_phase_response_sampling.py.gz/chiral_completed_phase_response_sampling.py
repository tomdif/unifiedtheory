#!/usr/bin/env python3
"""Resolve the completed scalar phase's fifth coefficient on a finite chart.

This is a generic 2^4 field, not the two-coordinate continuum refinement.
Odd polynomial fits at two amplitude ranges diagnose coefficient stability;
they are not rigorous derivative bounds or a continuum scaling estimate.
"""
import hashlib
import json
from pathlib import Path
import time

import numpy as np
import second_cohomology_audit as completion
from radial_measure_audit import RectangularOverlap

ROOT = Path(__file__).resolve().parents[1]


def main():
    started = time.time()
    model = RectangularOverlap((2,)*4)
    field = np.random.default_rng(261029019).uniform(-.15, .15, (4, model.n))
    # Charge homogeneity at the Taylor coefficient: sum m q^5 = 4320.
    # Computing a single charge avoids cancellation of the lower moments.
    completion.SPECIES = [('unit charge', 1, 1)]
    rows = []
    for amplitude in [.2, .3, .4, .5, .6, .75, .9, 1.]:
        result = completion.integrated_jets(model, amplitude*field,
                                           field_nodes=6, resolvent_nodes=40)
        rows.append(dict(amplitude=amplitude, correction=result['phase'],
                         audit=result['audit']))
        print('phase', amplitude, result['phase'], flush=True)
    fits = []
    for selection in [rows, rows[:5], rows[2:]]:
        x = np.array([r['amplitude'] for r in selection])
        y = np.array([r['correction'] for r in selection])/x**3
        degree = min(3, len(selection)-1)
        coefficients = np.polynomial.polynomial.polyfit(x*x, y, degree)
        predicted = np.polynomial.polynomial.polyval(x*x, coefficients)*x**3
        fits.append(dict(amplitudes=x.tolist(), odd_orders=list(range(3, 4+2*degree, 2)),
                         coefficients=coefficients.tolist(),
                         maximum_fit_residual=float(max(abs(predicted-np.array([r['correction'] for r in selection])))),
                         single_charge_phase_t5=float(coefficients[1]),
                         supplied_generation_current_t4_correction_imag=float(5*4320*coefficients[1])))
    report = dict(schema_version=1, field_seed=261029019, maximum_field=.15,
                  lengths=[2]*4, rows=rows, fits=fits, completed_phase_included=True,
                  continuum_scaling_proved=False,
                  convention='W_plus,completed = W_plus,Kato exp(+i C); delta beta = 5i [t^5] C',
                  scope='Finite-chart polynomial-fit diagnostic; distinct from the two-coordinate continuum field',
                  elapsed_seconds=time.time()-started)
    sources = ['scripts/chiral_completed_phase_response.py', 'scripts/second_cohomology_audit.py',
               'scripts/local_cohomology_audit.py', 'scripts/radial_measure_audit.py']
    report['source_sha256'] = {p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in sources}
    (ROOT/'data/chiral_completed_phase_response.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(fits, indent=2), flush=True)


if __name__ == '__main__':
    main()
