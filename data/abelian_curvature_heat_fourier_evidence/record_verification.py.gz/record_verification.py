from pathlib import Path
import datetime
import gzip
import hashlib
import json
import re
import subprocess

root = Path('/Users/thomasdifiore/unifiedtheory')
tmp = Path('/tmp/unifiedtheory-heat-continuum')
mods = ['AbelianCurvatureHeatFourier', 'AbelianCurvatureHeatContinuum', 'AbelianCurvatureHeatGridLimit']
expected = {}
for mod in mods:
    src = root / 'UnifiedTheory/LayerA' / (mod + '.lean')
    expected[mod] = ['UnifiedTheory.LayerA.' + mod + '.' + x for x in re.findall(r'^theorem (\w+)', src.read_text(), re.M)]
assert 'Build completed successfully' in (tmp / 'final-build.log').read_text()
raw = (tmp / 'axioms.log').read_text()
assert 'error:' not in raw
checked = {name: sorted(a.strip() for a in axioms.split(',') if a.strip())
           for name, axioms in re.findall(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]", raw)}
assert set(checked) == {name for group in expected.values() for name in group}, checked.keys()
allowed = {'propext', 'Classical.choice', 'Quot.sound'}
assert all(set(ax) <= allowed for ax in checked.values())
evidence = root / 'data/abelian_curvature_heat_fourier_evidence'
evidence.mkdir(exist_ok=True)
for filename in ['final-build.log', 'axioms.log', 'ym-ledger.log', 'toe-ledger.log']:
    (evidence / (filename + '.gz')).write_bytes(gzip.compress((tmp / filename).read_bytes(), mtime=0))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
sources = ['UnifiedTheory/LayerA/' + x + '.lean' for x in mods]
sources += ['UnifiedTheory/LayerA/AbelianCurvatureHeat.lean',
            'UnifiedTheory/LayerA/AbelianCurvatureHeatDynamics.lean',
            'scripts/CheckAbelianCurvatureHeatFourier.lean',
            'scripts/audit_repository.py', 'scripts/check_yang_mills_requirements.py',
            'scripts/validate_toe_attack_ledger.py',
            'ABELIAN_CURVATURE_HEAT_LIMIT.md', 'OPEN_OBLIGATIONS_ATTACK.md', 'README.md', 'STATUS.md',
            'lean-toolchain', 'lakefile.toml', 'lake-manifest.json']
report = {
  'schema_version': 1,
  'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
  'scope': 'Fourier continuation of the actual classical Abelian grid heat; no physical Yang-Mills or TOE completion',
  'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
  'workspace_state': 'Local uncommitted work; unrelated pre-existing changes preserved',
  'build': {'passed': True, 'target': 'UnifiedTheory.LayerA.AbelianCurvatureHeatGridLimit', 'whole_repository_build': False},
  'axiom_check': {'passed': True, 'checked_declarations': len(checked), 'allowed_axioms': sorted(allowed), 'declarations': checked},
  'modules': {m: {'theorem_count': len(ns)} for m, ns in expected.items()},
  'main_result': {
    'declaration': 'UnifiedTheory.LayerA.AbelianCurvatureHeatGridLimit.gridHeat_perturbed_reconstruction_limit',
    'hypotheses': [
      'Uniform complex coefficient bounds for every grid and integer frequency',
      'Coefficient convergence at every fixed frequency',
      'Fixed strictly positive diffusion time',
      'Initial grid values differ from the real Fourier reconstruction by eta_n tending to zero'],
    'conclusion': 'The actual gridHeat converges uniformly over all nodes to the real part of the continuum Fourier series',
    'frequency_window': '-1/2 <= h*k_j < 1/2 in each coordinate',
    'grid_size': 'n+1',
    'rate_claimed': False,
    'uniform_over_time_intervals_claimed': False
  },
  'additional_results': [
    'Exact Fourier diagonalization of the original Poisson heat for every real datum on a finite additive group',
    'Actual grid characters have the stated sine-squared eigenvalues',
    'Every polynomially weighted Gaussian on the integer frequency plane is summable',
    'Discrete eigenvalues tend to their continuum values',
    'The full positive-time series converges uniformly in space',
    'The coefficient error tends to zero under every fixed polynomial frequency weight',
    'The continuum series is spatially continuous'],
  'remaining_formal_obligations': [
    'Construct the original cell-average Fourier coefficients, prove their bounds and consistency, and identify their reconstruction with the specified grid data',
    'Differentiate the continuum series and establish the PDE, L2 initial trace, and uniqueness',
    'Prove the quantitative estimates uniformly over positive time intervals and assemble the gauge and path-transport estimates'],
  'physical_ledgers': {
    'yang_mills': json.loads((tmp / 'ym-ledger.log').read_text()),
    'toe': (tmp / 'toe-ledger.log').read_text().strip(),
    'gate_statuses_changed': False
  },
  'prior_reports': 'Earlier repository, heat, and open-obligation JSON records are historical checkpoints; this record covers the new source and documentation versions.',
  'source_sha256': {s: sha(root / s) for s in sources},
  'evidence_sha256': {str(p.relative_to(root)): sha(p) for p in sorted(evidence.glob('*.gz'))}
}
path = root / 'data/abelian_curvature_heat_fourier_verification.json'
path.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'checked_declarations': len(checked), 'all_allowed_axioms': True, 'report': str(path)}))
